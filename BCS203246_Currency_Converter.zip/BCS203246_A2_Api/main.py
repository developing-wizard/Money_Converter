import requests
import tkinter as tk
from tkinter import ttk

# create the Tkinter window
window = tk.Tk()
window.title("Muhammad Talha Currency Converter")

# set the window size
window.geometry("400x400")

# set the background color
window.configure(background='black')

# get the currency exchange rates from the internet
response = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
rates = response.json()['rates']

# create the available currencies list
available_currencies = list(rates.keys())

# create the ttk style object
style = ttk.Style()

# define the 'red' style for the button widget
style.configure('Red.TButton', foreground='red')
# create the input widgets
amount_label = ttk.Label(window, text="Enter amount:")
amount_label.configure(background='black', foreground='red')
amount_label.pack(padx=0, pady=20)

amount_entry = ttk.Entry(window)
amount_entry.pack()

currency_from_label = ttk.Label(window, text="From:")
currency_from_label.configure(background='black', foreground='red')
currency_from_label.pack(pady=10)

currency_from_menu = ttk.Combobox(window, values=available_currencies, state="readonly")
currency_from_menu.pack()

currency_to_label = ttk.Label(window, text="To:")
currency_to_label.configure(background='black', foreground='red')
currency_to_label.pack(pady=10)

currency_to_menu = ttk.Combobox(window, values=available_currencies, state="readonly")
currency_to_menu.pack()

result_label = ttk.Label(window, text="")
result_label.configure(background='black', foreground='red')
result_label.pack(pady=20)

# create the conversion function
def convert_currency():
    # get the input values
    amount = float(amount_entry.get())
    currency_from = currency_from_menu.get()
    currency_to = currency_to_menu.get()

    # convert the currency
    result = amount * rates[currency_to] / rates[currency_from]

    # update the result label
    result_label.configure(text=f"{amount:.2f} {currency_from} is equal to {result:.2f} {currency_to}")

# create the conversion button
convert_button = ttk.Button(window, text="Convert", command=convert_currency, style='Red.TButton')
convert_button.pack(pady=5)

# create the reset button
def reset():
    amount_entry.delete(0, 'end')
    currency_from_menu.set('')
    currency_to_menu.set('')
    result_label.configure(text="")

reset_button = ttk.Button(window, text="Reset", command=reset,style='Red.TButton')
reset_button.pack(pady=10)

# run the Tkinter event loop
window.mainloop()
